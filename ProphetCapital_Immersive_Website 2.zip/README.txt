# Prophet Capital — Immersive Website

A self-contained, high-end Prophet Capital landing site using the supplied dove/Prophet Capital image as the visual foundation.

## Included
- `index.html` — complete website
- `styles.css` — responsive luxury dark/neon styling
- `app.js` — Three.js ambient particle field, 3D card tilt, scroll reveals and parallax
- `assets/prophet-capital-dove.jpeg` — the exact supplied reference image

## Deploy
Upload the contents of this folder to Netlify, Vercel, GitHub Pages, or any static hosting service.

The site uses Google Fonts and Three.js from CDNs. For a completely offline version, download those dependencies locally and replace the CDN references in `index.html`.

## Customize
Update the email, phone, and section copy in `index.html`.
