// Prophet Capital immersive experience
const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];

window.addEventListener('load', () => {
  setTimeout(() => $('#preloader')?.classList.add('hide'), 900);
  $('#year').textContent = new Date().getFullYear();
});

// Scroll reveal
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.14 });
$$('.reveal').forEach(el => observer.observe(el));

// Subtle 3D card interaction
$$('[data-tilt]').forEach(card => {
  card.addEventListener('pointermove', (e) => {
    const r = card.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width;
    const y = (e.clientY - r.top) / r.height;
    const rx = (0.5-y) * 9;
    const ry = (x-0.5) * 10;
    card.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg) translateZ(7px)`;
    card.style.setProperty('--mx', `${x*100}%`);
    card.style.setProperty('--my', `${y*100}%`);
  });
  card.addEventListener('pointerleave', () => {
    card.style.transform = '';
  });
});

// Three.js ambient particle field
(function initSpace(){
  if (!window.THREE) return;
  const canvas = document.getElementById('space');
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(55, innerWidth/innerHeight, 0.1, 1000);
  camera.position.z = 8;

  const renderer = new THREE.WebGLRenderer({canvas, alpha:true, antialias:true});
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setSize(innerWidth, innerHeight);
  renderer.setClearColor(0x000000, 0);

  const count = 950;
  const positions = new Float32Array(count*3);
  const scales = new Float32Array(count);
  for(let i=0;i<count;i++){
    positions[i*3] = (Math.random()-.5)*18;
    positions[i*3+1] = (Math.random()-.5)*11;
    positions[i*3+2] = (Math.random()-.5)*14;
    scales[i] = .4 + Math.random()*1.8;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions,3));
  geo.setAttribute('aScale', new THREE.BufferAttribute(scales,1));

  const mat = new THREE.PointsMaterial({
    color: 0x5dff67,
    size: 0.018,
    transparent: true,
    opacity: .45,
    blending: THREE.AdditiveBlending,
    depthWrite:false
  });
  const stars = new THREE.Points(geo,mat);
  scene.add(stars);

  const ringGeo = new THREE.TorusGeometry(3.4,.008,8,160);
  const ringMat = new THREE.MeshBasicMaterial({color:0x39ff4b,transparent:true,opacity:.18});
  const ring = new THREE.Mesh(ringGeo,ringMat);
  ring.rotation.x = Math.PI*.62;
  ring.rotation.y = Math.PI*.18;
  scene.add(ring);

  let mx=0,my=0,tx=0,ty=0;
  addEventListener('pointermove',e=>{
    tx=(e.clientX/innerWidth-.5);
    ty=(e.clientY/innerHeight-.5);
  });
  addEventListener('resize',()=>{
    camera.aspect=innerWidth/innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth,innerHeight);
  });

  function animate(t){
    requestAnimationFrame(animate);
    mx += (tx-mx)*.025;
    my += (ty-my)*.025;
    stars.rotation.y = t*.000035 + mx*.12;
    stars.rotation.x = t*.00002 + my*.08;
    ring.rotation.z = t*.00006;
    ring.position.x = mx*.35;
    ring.position.y = -my*.2;
    camera.position.x = mx*.22;
    camera.position.y = -my*.15;
    camera.lookAt(0,0,0);
    renderer.render(scene,camera);
  }
  animate(0);
})();

// Background parallax based on scroll
const photo = $('.hero-photo');
addEventListener('scroll', () => {
  if(!photo) return;
  const y = Math.min(scrollY, innerHeight);
  photo.style.transform = `scale(${1.06 + y/innerHeight*.05}) translate3d(0,${y*.035}px,0)`;
}, {passive:true});
